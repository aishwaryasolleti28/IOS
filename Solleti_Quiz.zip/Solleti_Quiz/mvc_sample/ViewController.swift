//
//  ViewController.swift
//  mvc_sample
//
//  Created by Created by Solleti,Aishwarya on 4/4/23.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "resultSegue"{
                var destination = segue .destination as! ResultViewController
                
            }
        }
}

